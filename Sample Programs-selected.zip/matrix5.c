//To display 2D array with double pointer function call

#include<stdio.h>
#define R 2
#define C 2

void print4(int **sp);

main()
{
    int i;
    int A[R][C]={1,2,3,4};
    int **s;
    *s=&A[0][0];
    print4(s);
}
void print4(int **sp)
{
    int i,j;

    for(i=0;i<R;i++)
    {
        for(j=0;j<C;j++)
        {
            printf("%d ",**sp);
            (*sp)++;
        }
        printf("\n");
    }

    /*for(i=0;i<R*C;i++,(*sp)++)
        printf("%d ",**sp);*/
}
