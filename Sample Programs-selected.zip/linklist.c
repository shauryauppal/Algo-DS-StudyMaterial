#include<stdio.h>
#include<stdlib.h>
typedef struct Node
{
        int data;
        struct Node *next;
}node;
void insert(node *t, int d)
{
        // traverse till end
        while(t->next!=NULL)
            t=t->next;

        // dynamically allocate memory for new node
        t->next = (node *)malloc(sizeof(node));
        t = t->next;
        t->data = d;
        t->next = NULL;
}
void print(node *t)
{
        while(t!=NULL)
        {
            printf("%d ",t->data);
            t=t->next;
        }
}
main()
{

        int x, max=0;
        node *head,*temp;
        head = (node *)malloc(sizeof(node));
        temp = head;
        temp -> next = NULL;

        //data entry
        while(max<5)
        {
            scanf("%d",&x);
            insert(head,x);
            max++;
        }

        printf("The list is ");
        print(head->next);
        printf("\n");
}


