#include<stdio.h>
#include<stdlib.h>

typedef struct Node
{
        int data;
        struct Node *next;
}node;

void print(node *t)
{
        while(t!=NULL)
        {
            printf("%d ",t->data);
            t=t->next;
        }
}
main()
{

        int x;
        int ch=-1;
        node *head,*temp;
        head=(node*)malloc(sizeof(node));

        //data entry
        do
        {
            printf("Enter data: ");
            scanf("%d",&x);

            if(ch==-1)
            {
                temp=head;
                temp->data=x;
            }
            else
            {
                temp->next=(node*)malloc(sizeof(node));
                temp=temp->next;
                temp->data=x;
            }

            printf("Do you want to create another node (yes=1/no=0): ");
            scanf("%d",&ch);

        }while(ch==1);

        temp->next=NULL;

        // print list
        printf("The list is: ");
        print(head);
        printf("\n");
}
