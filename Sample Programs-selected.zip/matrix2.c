//To display 2D array with function, without pointer

#include<stdio.h>
#define R 2
#define C 2

void print1(int a[R][C]);      //No pointer function call for 2D array

main()
{
    int A[R][C]={1,2,3,4};
    print1(A);
}
void print1(int a[R][C])
{
    int i,j;
    for(i=0;i<R;i++)
    {
        for(j=0;j<C;j++)
        {
            printf("%d ",a[i][j]);      //No pointer referencing
        }
        printf("\n");
    }
    printf("\n\n");
}
