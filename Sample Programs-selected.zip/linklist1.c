#include<stdio.h>
#include<stdlib.h>
#define MAX 5

typedef struct Node
{
        int data;
        struct Node *next;
}node;

void insert(node *t, int d)
{
     while(t->next!=NULL)
          t=t->next;

        t->next=(node*)malloc(sizeof(node));
        t=t->next;
        t->data=d;
        t->next=NULL;

}

void print(node *t)
{
        while(t!=NULL)
        {
            printf("%d ",t->data);
            t=t->next;
        }
}

main()
{

        int x,i;
        node *head,*t;
        head=(node*)malloc(sizeof(node)); // dynamically allocate memory for new node
        head->next=NULL;

        //data entry
        while(i<MAX)
        {
            printf("Enter data: ");
            scanf("%d",&x);
            insert(head,x);
            i++;
        }

        printf("The list is ");
        print(head->next);
        printf("\n");
}
