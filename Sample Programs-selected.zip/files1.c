//To read contents of a file and print on terminal (character by character)

#include<stdio.h>
main()
{
    FILE *fp;
    char ch;

    fp=fopen("f1.txt","r");

    ch=fgetc(fp);
    while(ch!=EOF)
    {
        printf("%c",ch);
        ch=fgetc(fp);
    }

    fclose(fp);
}
