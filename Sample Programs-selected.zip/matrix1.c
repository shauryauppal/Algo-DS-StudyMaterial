//To demonstrate different ways of referencing 2D array elements

#include<stdio.h>
#define R 2
#define C 2

main()
{
    int A[R][C]={1,2,3,4};
    int i,j;
    printf("Enter Array Contents\n\n");
    for(i=0;i<R;i++)
    {
        for(j=0;j<C;j++)
        {
            printf("%d ",A[i][j]);          //No pointer referencing
            printf("%d ",*(A[i]+j));        //Single pointer referencing
            printf("%d ",(*(A+i))[j]);      //Single pointer referencing
            printf("%d ",*(*(A+i)+j));      //Double pointer referencing
            printf("%d ",*(*A+(i*C)+j));    //Double pointer referencing

        }
        printf("\n");
    }
}
