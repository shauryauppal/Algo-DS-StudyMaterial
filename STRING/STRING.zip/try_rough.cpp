#include <iostream>
#include <cstdio>
#include <cmath>
using namespace std;
int main()
{
    int i=0,n=0,a[10000],small=0;
    cin>>n;
    for(int i=0;i<n;i++)
    {
        cin>>a[i];
    }
    int ct=0,zero=0;
    int p=n;
    while(p!=1)
    {   ct=0;p=n;zero=0,i=0;
        while(i<n)
        {
                if(a[i])
                {
                    small=a[i];
                    break;
                }
                i++;
        }
        for(int i=0;i<n;i++)
        {
            if(a[i]!=0)
            {
                if(small>a[i])
                small=a[i];
            }
        }
        for(int i=0;i<n;i++)
        {
            if(a[i]!=0)
                ct++;
            else if(a[i]==0)
                zero++;
        }
        p=p-zero;
        for(int i=0;i<n;i++)
        {
            if(a[i]>0)
            {
                a[i]=a[i]-small;
            }
        }
        cout<<ct<<'\n';
    }
    return 0;
}
