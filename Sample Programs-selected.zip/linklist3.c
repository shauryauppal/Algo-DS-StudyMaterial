// To delete element from end

#include<stdio.h>

typedef struct Node{
    int data;
    struct Node *next;
    }node;

node* makelist();
node* create(int);
void print(node*);

main()
{
    node *head,*t,*s;
    int ch;
    head=makelist();

    do
    {

        if (head==NULL)
        {
            printf("Nothing to delete.. List is empty");
        }
        else
        {
            t=head;
            while(t->next!=NULL)
            {
                s=t;
                t=t->next;
            }
            s->next=NULL;
        }
        printf("Element deleted from end... Want to delete more? ");
        scanf("%d",&ch);
    }while(ch!=0); //0 means "no" & non-zero means "yes"

    printf("\nAfter Deletion list is : ");
    print(head);

}

node* makelist()
{
    int d,ch;
    node *head=NULL,*p;

    do
    {
        printf("Enter Data: ");
        scanf("%d",&d);
        if (head==NULL)
        {
            head=create(d);
            p=head;
        }
        else
        {
            p->next=create(d);
            p=p->next;
        }
        printf("More Elements: ");
        scanf("%d",&ch);
    }while(ch!=0);

    print(head);
    return head;
}

void print(node *q)
{
    while(q!=NULL)
    {
        printf(" %d ",q->data);
        q=q->next;
    }
}

node* create(int data)
{
    node *q=malloc(sizeof(node*));
    q->data=data;
    q->next=NULL;
    return q;
}
