//To display 2D array with single pointer function call

#include<stdio.h>
#define R 2
#define C 2

void print2(int *sp);

main()
{
    int A[R][C]={1,2,3,4};
    int *s=&A;
    print2(s);
}
void print2(int *sp)
{
    int i,j;
    for(i=0;i<R;i++)
    {
        for(j=0;j<C;j++)
        {
            printf("%d ",*(sp+(i*C)+j));
        }
        printf("\n");
    }
}
