// Queue-based computation of leaf nodes
#include <stdio.h>
#include <stdlib.h>
#define MAX_Q_SIZE 500

struct node
{
int data;
struct node* left;
struct node* right;
};

int countLeaf(struct node *);
struct node** createQueue(int *, int *);
void enQueue(struct node **, int *, struct node *);
struct node *deQueue(struct node **, int *);

int countLeaf(struct node *root)
{
int rear, front, i,leaf=0;
int cnt1 = 1, cnt2;
struct node **queue = createQueue(&front, &rear);
struct node *temp = root;

while (temp)
{
cnt2 = 0;
for(i = 0; i < cnt1; i++)
{
//Enqueue left child
if (temp->left){
enQueue(queue, &rear, temp->left);
cnt2++;
}

//Enqueue right child
if (temp->right){
cnt2++;
enQueue(queue, &rear, temp->right);
}

//Dequeue node
temp=deQueue(queue, &front);
if ((temp!=NULL)&&((temp->left==NULL)&&(temp->right==NULL)))
leaf++;
}
cnt1 = cnt2;
}
return (leaf);
}

struct node** createQueue(int *front, int *rear)
{
struct node **queue=(struct node **)malloc(sizeof(struct node*)*MAX_Q_SIZE);
*front = *rear = 0;
return queue;
}

void enQueue(struct node **queue, int *rear, struct node *new_node)
{
queue[*rear] = new_node;
(*rear)++;
}

struct node *deQueue(struct node **queue, int *front)
{
(*front)++;
return queue[*front - 1];
}

struct node* newNode(int data)
{
struct node* node=(struct node*)malloc(sizeof(struct node));
node->data = data;
node->left = NULL;
node->right = NULL;
return(node);
}

void main()
{
int x=0;
struct node *root = newNode(1);
root->left = newNode(2);
root->right = newNode(3);
root->left->left = newNode(4);
root->left->right = newNode(5);
root->right->left = newNode(6);
//root->right->right = newNode(7);
printf("No. of Leaf Nodes = ");
x=countLeaf(root);
printf("%d\n",x);
}
